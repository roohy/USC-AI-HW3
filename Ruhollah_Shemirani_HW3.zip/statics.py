__author__ = 'roohy'

variable_list = ['x']

unary_functions = {}
binary_functions = {}

implications = []
